<?php
$pdo = new PDO("mysql:host=localhost;dbname=ogloszenia;charset=utf8", "root", "");
?>